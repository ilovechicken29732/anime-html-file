// List all your games here
const games = [
  { name: "2048", description: "Classic tile merging puzzle.", path: "2048.html.txt" },
  { name: "Bloons Tower Defense 5", description: "Defend your base from bloons!", path: "bloonstowerdefense5.html.txt" },
  { name: "Bloxorz", description: "Roll your block to the goal!", path: "bloxorz.html.txt" },
  { name: "Evil Glitch", description: "Survive the evil glitch!", path: "evilglitch.html.txt" },
  { name: "Geometry Dash", description: "Jump and fly your way through danger!", path: "geometrydash.html.txt" },
  { name: "Ninja vs Evil Corp", description: "Slash through enemies in this ninja action game.", path: "ninjavsevilcorp.html.txt" },
  { name: "Radius Raid", description: "Blast enemies in circular space combat.", path: "radiusraid.html.txt" },
  { name: "Slope", description: "Dodge obstacles as you roll down the slope.", path: "slope.html.txt" },
  { name: "Spacebar Clicker", description: "How fast can you click?", path: "spacebarclicker.html.txt" },
  { name: "Stickman Hook", description: "Swing your stickman to victory!", path: "stickmanhook.html.txt" },
  { name: "Super Mario 64", description: "Play the classic Mario adventure.", path: "supermario64.html.txt" }
];

const gamesList = document.getElementById('games-list');
games.forEach(game => {
  const card = document.createElement('div');
  card.className = 'game-card';
  card.innerHTML = `
    <div class="game-title">${game.name}</div>
    <div class="game-desc">${game.description}</div>
  `;
  card.addEventListener('click', () => openGame(game.path));
  gamesList.appendChild(card);
});

// Modal logic
const modal = document.getElementById('game-modal');
const frame = document.getElementById('game-frame');
const closeBtn = document.getElementById('close-modal');
function openGame(path) {
  frame.src = path;
  modal.classList.remove('hidden');
}
closeBtn.addEventListener('click', () => {
  frame.src = "";
  modal.classList.add('hidden');
});
modal.addEventListener('click', (e) => {
  if (e.target === modal) {
    frame.src = "";
    modal.classList.add('hidden');
  }
});

// Search
document.getElementById('search').addEventListener('input', function() {
  const filter = this.value.toLowerCase();
  document.querySelectorAll('.game-card').forEach(card => {
    card.style.display = card.innerText.toLowerCase().includes(filter) ? '' : 'none';
  });
});